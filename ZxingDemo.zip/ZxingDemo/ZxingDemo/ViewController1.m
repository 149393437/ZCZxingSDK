//
//  ViewController1.m
//  ZxingDemo
//
//  Created by ZhangCheng on 13-12-10.
//  Copyright (c) 2013年 ZhangCheng. All rights reserved.
//

#import "ViewController1.h"
#import "ZCZxingViewController.h"

@interface ViewController1 ()

@end

@implementation ViewController1

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    UIButton*button=[UIButton buttonWithType:UIButtonTypeContactAdd];
    button.frame=CGRectMake(100, 100, 100, 100);
    [self.view addSubview:button];
    [button addTarget:self action:@selector(aa) forControlEvents:UIControlEventTouchUpInside];

	// Do any additional setup after loading the view.
}

-(void)aa{

    ZCZxingViewController*vc=[[ZCZxingViewController alloc]initWithBlock:^(NSString *str, BOOL isScceed) {
        if (isScceed) {
            NSLog(@"扫描成功~%@",str);
        }else{
            NSLog(@"扫描失败");
        }
    }];
    
       [self presentViewController:vc animated:YES completion:nil];
}

    
    



- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
