//
//  main.m
//  ZxingDemo
//
//  Created by ZhangCheng on 13-12-10.
//  Copyright (c) 2013年 ZhangCheng. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "AppDelegate.h"

int main(int argc, char *argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
