//
//  AppDelegate.h
//  ZxingDemo
//
//  Created by ZhangCheng on 13-12-10.
//  Copyright (c) 2013年 ZhangCheng. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
